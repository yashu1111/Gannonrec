import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";

import Home from "./components/Home";
import Login from "./components/Login";
import Signup from "./components/Signup";
import About from "./components/About";
import Forgot from "./components/Forgot";
import Dashbaord from "./components/Activity/Dashboard";
import MyActivities from "./components/Activity/MyActivities";
import Profile from "./components/profile/Profile";
import Activities from "./components/Activity/Activities";
import FacilitySchedule from "./components/Activity/FacilitySchedule";
import NotFound from "./components/NotFound";

import { useSelector } from "react-redux";

function App() {
  const auth = useSelector((state) => state.auth);
  return (
    <Router>
      <Routes>
        {auth.isLoggedIn && auth.user !== null ? (
          <Route path="/" element={<Dashbaord />} />
        ) : (
          <Route path="/" element={<Home />} />
        )}
        <Route path="/dashboard" element={<Dashbaord />} />
        <Route path="/myactivities" element={<MyActivities />} />
        <Route path="/login" element={<Login />} />
        <Route path="/signup" element={<Signup />} />
        <Route path="/about" element={<About />} />
        <Route path="/forgot" element={<Forgot />} />
        <Route path="/account" element={<Profile />} />
        <Route path="/activities" element={<Activities />} />
        <Route path="/facilityschedule" element={<FacilitySchedule />} />
        <Route path="*" element={<NotFound />} />
      </Routes>
    </Router>
  );
}

export default App;
