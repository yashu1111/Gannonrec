import React from 'react';

function Navbar() {
  return (
    <nav className="bg-red-900 p-4 text-yellow-400">
        <div className="container mx-auto flex justify-between">
          <div className="flex items-center space-x-4">
            <img
              alt="Gannon University Logo"
              className="h-10 w-auto"
              src="https://images.squarespace-cdn.com/content/v1/5d48a985b59b1600014c7794/1574396720383-3LECB7ZYTXMZHL3TQ59R/LogoRayBelieve_300.png"
            />
            <span className="hidden sm:block">Welcome to GannonRecConnect</span>
          </div>
          <div className="flex items-center space-x-4">
            <a className="hover:underline" href="/">
              Home
            </a>
            <a className="hover:underline" href="/login">
              Login
            </a>
            <a className="hover:underline" href="/signup">
              Signup
            </a>
            <a className="hover:underline" href="/about">
              About Us
            </a>
          </div>
        </div>
      </nav>
  );
}

export default Navbar;
