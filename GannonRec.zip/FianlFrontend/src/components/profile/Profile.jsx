// UserProfile.jsx
import React, { useState } from 'react';
import EditInput from './EditInput';
import UserNav from '../Activity/UserNav';
import { Card } from '../ui/card';
import { useSelector } from 'react-redux';
import { updateUser  } from '../../api/api';
import { useDispatch } from "react-redux";
import { logout, login } from "../../store/authSlice";
import { Navigate } from 'react-router-dom';

const Account = () => {
  const auth = useSelector((state) => state.auth);

  const [name, setName] = useState(auth.user?.name);
  const [email, setEmail] = useState(auth.user?.email);
  const [isEditingName, setEditingName] = useState(false);
  const [isEditingEmail, setEditingEmail] = useState(false);
  const [isEditingPassword, setEditingPassword] = useState(false);
  const dispatch = useDispatch();
  
  const handleNameSave = async (newName) => {
    setName(newName);
    await updateUser(auth.user._id, {name: newName}).then((response) => {
      if(response.status === 200) {
        dispatch(login(response.data.user));
      }
    }).catch((error) => {
      console.log(error);
    });
    setEditingName(false);
  };

  const handleEmailSave = async (newEmail) => {
    setEmail(newEmail);
    await updateUser(auth.user._id, {email: newEmail}).then((response) => {
      dispatch(logout());
      console.log(response);  
    }).catch((error) => {
      console.log(error);
    });
    setEditingEmail(false);
  };

  const handlePasswordSave = async (newPassword) => {
    await updateUser(auth.user._id, {password: newPassword}).then((response) => {
    dispatch(logout());
    }
    ).catch((error) => {
      console.log(error);
    });
    setEditingPassword(false);
  };

  return (
      <div className="flex flex-col space-x-4 p-20 items-center">
        <Card>
          {isEditingName ? 
            <EditInput type="text" _input={name} onSave={handleNameSave} onCancel={() => setEditingName(false)} />
          : 
            <div className="flex items-center p-5 m-5 text-2xl rounded "><b>Name : </b> {name} <button className="ml-2 text-white p-2 text-xl rounded" onClick={() => setEditingName(true)}>✏️</button></div>
          }
          {isEditingEmail ? 
            <EditInput type="email" _input={email} onSave={handleEmailSave} onCancel={() => setEditingEmail(false)} />
          :
            <div className="flex items-center p-5 m-5 text-2xl rounded "><b>Email : </b> {email} <button className="ml-2 text-white p-2 text-xl rounded" onClick={() => setEditingEmail(true)}>✏️</button></div>
          }
          {isEditingPassword ? 
            <EditInput type="password" _input={""} onSave={handlePasswordSave} onCancel={() => setEditingPassword(false)} />
          :
            <div className="flex items-center p-5 m-5 text-2xl rounded ">Password <button className="ml-2 text-white p-2 text-xl rounded" onClick={() => setEditingPassword(true)}>✏️</button></div>
          }
        </Card>
      </div>
  );
}



export default function Profile() {

  const auth = useSelector((state) => state.auth);

  return (
    <div>
      {auth.isLoggedIn ? <UserNav heading={`My Account`} Component={Account} /> : <Navigate to="/login" />}
    </div>
  )
}
