import React, { useState } from 'react';

const EditInput = ({ _input, onSave, type = "text", onCancel }) => {
  const [newInput, setNewInput] = useState(_input);

  const handleSave = () => {
    onSave(newInput);
  };

  return (
    <div className="flex items-center p-5 m-5 bg-white rounded">
      <input
        type={type}
        value={newInput}
        onChange={(e) => setNewInput(e.target.value)}
        placeholder="Enter your input"
        className="border-2 border-gray-200 p-2 rounded"
      />
      <button onClick={handleSave} className="ml-2 bg-blue-500 hover:bg-green-600 text-white p-2 rounded">✔</button>
      <button onClick={onCancel} className="ml-2 bg-red-500 hover:bg-red-600 text-white p-2 rounded">✖</button>
    </div>
  );
};

export default EditInput;
