import { CardTitle, CardDescription, CardHeader, CardContent, CardFooter, Card } from "./ui/card"
import { Label } from "./ui/label"
import { Input } from "./ui/input"
import { Button } from "./ui/button"
import { Link } from "./ui/link"
import Navbar from "./Nav"

import { useState } from 'react';

import { forgotPassword } from '../api/api';


export default function Forgot() {

  const [email, setEmail] = useState('');
  const [emailError, setEmailError] = useState('');
  const [success, setSuccess] = useState('');
  const validateEmail = () => {
    if (!email) {
      setEmailError('Email is required');
      return;
    }
    else if (!/\S+@+\S+\.\S+/.test(email)) {
      setEmailError('Email is invalid');
      return;
    }
    // else if (!/\S+@gannon.edu+/.test(email)) {
    //   setEmailError('Email is invalid or not a Gannon email');
    //   return;
    // }
    setEmailError('');
  }

  const handleSubmit = async (e) => {
    e.preventDefault();
    validateEmail();
    if (!emailError) {
      await forgotPassword(email).then((response) => {
        response = response.response? response.response : response;
        if (response.data.message) {
          setSuccess(response.data.message);
          setEmailError('');
        }
        else {
          setEmailError(response.data.error);
          setSuccess('');
        }
      });
    }
  }
  
  return (
    <div>
      <Navbar />
      <div className="flex justify-center items-center h-screen">
      <Card className="mx-auto max-w-sm">
        <CardHeader className="space-y-1">
          <CardTitle className="text-2xl font-bold">Forgot password</CardTitle>
          <CardDescription>Enter your email below to reset your password</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="email">Email</Label>
            <Input id="email" type="email" onChange={(e) => setEmail(e.target.value)} placeholder="example@mail.com" />
          </div>
          <p className="text-red-500 text-sm">{emailError}</p>
          <p className="text-green-500 text-sm">{success}</p>
          <Button className="w-full" type="submit" onClick={handleSubmit}>  
            Submit
          </Button>
        </CardContent>
        <CardFooter>
          <Link className="text-sm underline" href="/login">
            Back to login
          </Link>
        </CardFooter>
      </Card>
    </div>
  </div>
  )
}
