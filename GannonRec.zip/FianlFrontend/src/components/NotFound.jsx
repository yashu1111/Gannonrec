import {Link} from "./ui/Link"

export default function NotFound() {
  return (
    <div className="flex flex-col items-center justify-center h-[100dvh] bg-gray-100 dark:bg-gray-900 p-4">
      <div className="max-w-md text-center space-y-4">
        <h1 className="text-8xl font-bold text-gray-800 dark:text-gray-200">404</h1>
        <p className="text-lg text-gray-600 dark:text-gray-400">Oops, the page you're looking for can't be found.</p>
        <Link
          className="inline-flex h-10 items-center justify-center rounded-md bg-gray-800 px-6 text-sm font-medium text-white shadow-sm transition-colors hover:bg-gray-900 focus:outline-none focus:ring-2 focus:ring-gray-500 focus:ring-offset-2 dark:bg-gray-200 dark:text-gray-800 dark:hover:bg-gray-300 dark:focus:ring-gray-400 dark:focus:ring-offset-gray-900"
          href="/"
        >
          Go back home
        </Link>
      </div>
    </div>
  )
}
