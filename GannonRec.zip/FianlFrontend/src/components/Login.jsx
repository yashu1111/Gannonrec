import {useState} from 'react';
import Navbar from './Nav';
import { Input } from "./ui/input";
import { Link } from "./ui/link";
import { Button } from "./ui/button";

import { useSelector, useDispatch } from 'react-redux';
import { userLogin } from '../api/api';
import { login } from '../store/authSlice';
import { Navigate } from 'react-router-dom'

import Verify from './Verify';

const Login = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState(null);
  const [verifyPopup, setVerifyPopup] = useState(false);

  const auth = useSelector((state) => state.auth);
  const dispatch = useDispatch();

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      if(!email || !password) return setError('Please fill in all fields');
      else setError(null);
      const response = await userLogin(email, password);
      console.log(response);
      if (response.existingUser) dispatch(login(response.existingUser));
      else if (response.data.verified) setVerifyPopup(true);
      else if (response.data.message) setError(response.data.message);
    }
    catch (error) {
      setError(error);
    }
  }
  return (
    <>
    {auth.isLoggedIn && auth.user !== null? <Navigate to="/" /> :
    <div>
      <Navbar/>
      {verifyPopup ? 
        <Verify email={email} 
                onSuccessfulVerification={(user) => dispatch(login(user))} 
                onClose={() => setVerifyPopup(false)} />:
      <div className="rounded-lg bg-white p-8 shadow-lg">
        <form className="space-y-6" onSubmit={handleSubmit}>
          <div className='flex items-center justify-center'>
            <div>
              <div>
                <label className="block text-sm font-medium text-gray-700" htmlFor="email">
                  Email
                </label>
                <Input
                  className="mt-1 block w-100 rounded-md border-gray-300 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50"
                  id="email"
                  placeholder="josh@email.com"
                  type="email"
                  onChange={(e) => setEmail(e.target.value)}
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700" htmlFor="password">
                  Password
                </label>
                <Input
                  className="mt-1 block w-100 rounded-md border-gray-300 shadow-sm focus:border-indigo-300 focus:ring focus:ring-indigo-200 focus:ring-opacity-50"
                  id="password"
                  placeholder="********"
                  type="password"
                  onChange={(e) => setPassword(e.target.value)}
                />
              </div>
              <div className="flex items-center justify-between">
                  <span className="text-sm text-red-600">{error}</span>
                </div>
              <div className='flex items-center justify-center'>
                <Button className="w-100 bg-indigo-600 hover:bg-indigo-700 focus:ring-4 focus:ring-indigo-300" onClick={handleSubmit} >Login</Button>
                <Link variant="link" href="/forgot" className='m-5' >
                    Forgot password?
                </Link>
              </div>
            </div>
          </div>
        </form>
        <div className="mt-8 text-center">
          <h2 className="text-lg font-semibold">Experience the best of campus recreation with</h2>
          <p className="text-xl font-bold text-indigo-600">GannonRecConnect</p>
          <p className="mt-2 text-sm text-gray-600">
            Your platform to join activities, meet like-minded students, and enrich your university experience.
          </p>
        </div>
        <div className="mt-8 grid grid-cols-2 gap-4">
          <div className="bg-gray-200 p-4 rounded-lg">
            <h3 className="text-lg font-semibold">Events Calendar</h3>
            <p className="text-sm text-gray-600 mt-2">Stay updated on upcoming events and activities.</p>
          </div>
          <div className="bg-gray-200 p-4 rounded-lg">
            <h3 className="text-lg font-semibold">Fitness Classes</h3>
            <p className="text-sm text-gray-600 mt-2">Join fitness classes to stay active and healthy.</p>
          </div>
          <div className="bg-gray-200 p-4 rounded-lg">
            <h3 className="text-lg font-semibold">Sports Teams</h3>
            <p className="text-sm text-gray-600 mt-2">Find and join sports teams to compete and have fun.</p>
          </div>
          <div className="bg-gray-200 p-4 rounded-lg">
            <h3 className="text-lg font-semibold">Social Groups</h3>
            <p className="text-sm text-gray-600 mt-2">Connect with various social groups and make new friends.</p>
          </div>
        </div>
      </div>
    }
    </div>
  }
  </>
  );
}

export default Login;
