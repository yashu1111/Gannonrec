import { CardTitle, CardHeader, CardContent, CardFooter, Card } from "../ui/card"
import { Button } from "../ui/button"
import { Label } from "../ui/label"
import { Input } from "../ui/input"
import { Textarea } from "../ui/textarea"

import { useState } from "react"

import { useSelector } from "react-redux"

import { createActivity, updateActivity } from "../../api/api"


export default function ActivityForm({ onSuccess, onClose, activity, isMyActivity }) {

  const [title, setTitle] = useState(activity ? activity.title : '');
  const [titleError, setTitleError] = useState('')
  const [sport, setSport] = useState(activity ? activity.sport : '');
  const [sportError, setSportError] = useState('')
  const [nbOfPlayers, setNbOfPlayers] = useState(activity ? activity.nbOfPlayers : '');
  const [nbOfPlayersError, setNbOfPlayersError] = useState('')
  const [privacy, setPrivacy] = useState(activity ? activity.type : 'Public');
  const [privacyError, setPrivacyError] = useState('')
  const [date, setDate] = useState(activity ? activity.date : '');
  const [dateError, setDateError] = useState('')
  const [time, setTime] = useState(activity ? activity.time : '');
  const [timeError, setTimeError] = useState('')
  const [description, setDescription] = useState(activity ? activity.description : '');
  const [descriptionError, setDescriptionError] = useState('')

  const auth = useSelector((state) => state.auth)

  let sportOptions = [
    "Football",
    "Basketball",
    "Volleyball",
    "Tennis",
    "Cricket",
    "Badminton",
    "Table Tennis",
    "Swimming",
    "Running",
    "Cycling",
    "Gym",
    "Yoga",
    "Others"
  ]

  const ValidateData = () => {
    let error = false
    if (!title) {
      setTitleError("Title is required")
      error = true
    }
    else if (title.length < 3) {
      setTitleError("Title must be at least 3 characters")
      error = true
    }
    else {
      setTitleError('')
    }

    if (sportOptions.indexOf(sport) === -1) {
      setSportError("Sport is required")
      error = true
    }
    else {
      setSportError('')
    }

    if (!nbOfPlayers) {
      setNbOfPlayersError("Number of players is required")
      error = true
    }
    else if (nbOfPlayers < 1) {
      setNbOfPlayersError("Number of players must be at least 1")
      error = true
    }
    else {
      setNbOfPlayersError('')
    }

    if (!privacy) {
      setPrivacyError("Privacy is required")
      error = true
    }
    else {
      setPrivacyError('')
    }

    if (!date) {
      setDateError("Date is required")
      error = true
    }
    else {
      setDateError('')
    }

    if (!time) {
      setTimeError("Time is required")
      error = true
    }
    else {
      setTimeError('')
    }

    if (!description) {
      setDescriptionError("Description is required")
      error = true
    }
    else if (description.length < 5) {
      setDescriptionError("Description must be at least 4 characters")
      error = true
    }
    else {
      setDescriptionError('')
    }
    return error;
  }

  const handleCreate = (event) => {
    event.preventDefault(); // Prevent default form submission



    if (!ValidateData()) {
      const data = {
        title: title,
        sport: sport,
        nbOfPlayers: nbOfPlayers,
        type: privacy,
        date: date,
        time: time,
        description: description,
        creator: auth.user._id
      };
      let response = createActivity(auth.user._id, data);
      response.then((activites) => {
        if (activites) {
          onSuccess(activites)
        }
      });
    }
  };

  const handleUpdate = (event) => {
    event.preventDefault()
    if(!ValidateData()){
      let data =
      {
        title: title,
        sport: sport,
        nbOfPlayers: nbOfPlayers,
        type: privacy,
        date: date,
        time: time,
        description: description
      }
      let response = updateActivity(activity._id, isMyActivity ? auth.user._id : false , data)
      response.then((activities) => {
        if (activities) {
          onSuccess(activities)
        }
      })
    }
  }


  return (
    <Card className="w-[500px] mx-auto mt-8">
      <CardHeader>
        <div className="flex justify-between items-center">
          <CardTitle>{activity ? 'Edit Activity' : 'Create Activity'}</CardTitle>
          <Button className="text-black" variant="ghost" onClick={onClose}>
            ✕
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        <form>
          <div className="grid w-full gap-4">
            <div className="flex flex-col space-y-1.5">
              <Label htmlFor="sport">Title</Label>
              <Input id="sport" placeholder="Title of the activity" value={title} onChange={(event) => setTitle(event.target.value)} />
              <span className="text-red-500">{titleError}</span>
            </div>
            <div className="flex flex-col space-y-1.5">
              <Label htmlFor="activity-name">Sports </Label>
              <select id="activity-name"
                className="flex h-10 w-full items-center justify-between rounded-md border border-slate-200 bg-white px-3 py-2 text-sm ring-offset-white placeholder:text-slate-500 focus:outline-none focus:ring-2 focus:ring-slate-950 focus:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50 [&>span]:line-clamp-1 dark:border-slate-800 dark:bg-slate-950 dark:ring-offset-slate-950 dark:placeholder:text-slate-400 dark:focus:ring-slate-300"
                value={sport}
                onChange={(event) => setSport(event.target.value)}>
                <option value="" disabled selected>Select Sport</option>
                {sportOptions.map((sport) => (
                  <option key={sport} value={sport}>
                    {sport}
                  </option>
                ))}
              </select>
              <span className="text-red-500">{sportError}</span>
            </div>
            <div className="flex flex-col space-y-1.5">
              <Label htmlFor="players">No of players</Label>
              <Input id="players" placeholder="5" value={nbOfPlayers} onChange={(event) => setNbOfPlayers(event.target.value)} />
              <span className="text-red-500">{nbOfPlayersError}</span>
            </div>
            <div className="flex flex-col space-y-1.5">
              <label htmlFor="privacy">Privacy</label>
              <select id="privacy"
                value={privacy}
                onChange={(event) => { setPrivacy(event.target.value); console.log(event.target.value) }}
                className="flex h-10 w-full items-center justify-between rounded-md border border-slate-200 bg-white px-3 py-2 text-sm ring-offset-white placeholder:text-slate-500 focus:outline-none focus:ring-2 focus:ring-slate-950 focus:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50 [&>span]:line-clamp-1 dark:border-slate-800 dark:bg-slate-950 dark:ring-offset-slate-950 dark:placeholder:text-slate-400 dark:focus:ring-slate-300"
              >
                <option value="Public">Public</option>
                <option value="Private">Private</option>
              </select>
              <span className="text-red-500">{privacyError}</span>
            </div>
            <div className="flex flex-col space-y-1.5">
              <Label htmlFor="date">Date</Label>
              <Input id="date" type="date" placeholder="dd-mm-yyyy" value={date} onChange={(event) => setDate(event.target.value)} />
              <span className="text-red-500">{dateError}</span>
            </div>
            <div className="flex flex-col space-y-1.5">
              <Label htmlFor="time">Time</Label>
              <Input id="time" type="time" placeholder="--:--" value={time} onChange={(event) => setTime(event.target.value)} />
              <span className="text-red-500">{timeError}</span>
            </div>
            <div className="flex flex-col space-y-1.5">
              <Label htmlFor="notes"></Label>
              <Textarea id="description" placeholder="Description" value={description} onChange={(event) => setDescription(event.target.value)} />
              <span className="text-red-500">{descriptionError}</span>
            </div>
          </div>
        </form>
      </CardContent>
      <CardFooter className="flex justify-center">
        <Button className="w-full" onClick={activity ? handleUpdate : handleCreate}  >{activity ? 'Update' : 'Create'}</Button>
      </CardFooter>
    </Card>
  )
}

