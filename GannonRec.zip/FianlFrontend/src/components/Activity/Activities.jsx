import { CardContent, CardFooter, Card } from "../ui/card"
import { Button } from "../ui/button"
import { Label } from "../ui/label"
import { Input } from "../ui/input"
import { useState, useEffect } from "react";
import { useSelector } from "react-redux"
import { Navigate } from "react-router-dom"
import { getActivities, deleteActivity, declineActivity, removeActivity, joinActivity } from "../../api/api"
import UserNav from "./UserNav"
import ActivityPopUp from "./ActivityPopUp";
import ActivityForm from "./ActivityForm"
import Success from "./Success";

function AllActivities() {
  const [isViewPopupVisible, setIsViewPopupVisible] = useState(false);
  const [isFormPopupVisible, setIsFormPopupVisible] = useState(false);
  const [activities, setActivities] = useState([])
  const [activity, setActivity] = useState(null)
  const [date, setDate] = useState('')
  const [sport, setSport] = useState('')
  const [filterButton, setFilterButton] = useState(true)
  const [isSuccessVisible, setIsSuccessVisible] = useState(false);
  const [successMessage, setSuccessMessage] = useState('')
  const auth = useSelector((state) => state.auth)


  let sportOptions = [
    "Football",
    "Basketball",
    "Volleyball",
    "Tennis",
    "Cricket",
    "Badminton",
    "Table Tennis",
    "Swimming",
    "Running",
    "Cycling",
    "Gym",
    "Yoga",
    "Others"
  ]

  useEffect(() => {
    if (auth.isLoggedIn) {
      getActivities().then((response) => {
        response = response.response ? response.response : response
        if (response.status === 200) {
          setActivities(response.data.activities)
        }
      })
    }
  }, [auth])

  const handleFilter = () => {
    if (filterButton) {
      let filteredActivities = activities.filter((activity) => {
        if (date && sport) {
          return activity.date === date && activity.sport === sport
        } else if (date) {
          return activity.date === date
        } else if (sport !== '') {
          return activity.sport === sport
        } else {
          return activity
        }
      })
      if (date === '' && sport === '') {
        setFilterButton(true)
      }
      else {
        setFilterButton(false)
      }
      setActivities(filteredActivities)
    } else {
      getActivities().then((response) => {
        response = response.response ? response.response : response
        if (response.status === 200) {
          setActivities(response.data.activities)
        }
      })
      setFilterButton(true)
      setDate('')
      setSport('')
    }
  }

  const handleDeletClick = async (activity) => {
    try {
      await deleteActivity(activity._id)
      getActivities().then((response) => setActivities(response.data.activities))
      setSuccessMessage("You have Deleted Activity")
      setIsSuccessVisible(true)
    }
    catch (error) {
      console.log(error)
    }
  }


  const handleViewClick = (activity) => {
    setActivity(activity)
    setIsViewPopupVisible(true);
  };

  const handleEditClick = (activity) => {
    setActivity(activity)
    setIsFormPopupVisible(true);
  }

  const handleJoinClick = (activity) => {
    joinActivity(activity._id, auth.user._id).then((response) => {
      response = response.response ? response.response : response
      if (response.status === 200) {
        setActivities(response.data.activities)
        setSuccessMessage(`You have ${activity.type === 'Public'? 'Joined':'Requested'} Activity`)
        setIsSuccessVisible(true)
      }
    })
  }

  const handleLeaveClick = (activity) => {
    removeActivity(activity._id, auth.user._id).then((response) => {
      response = response.response ? response.response : response
      if (response.status === 200) {
        setActivities(response.data.activities)
        setSuccessMessage("You Left Activity")
        setIsSuccessVisible(true)
      }
    })
  }

  const handleCancleClick = (activity) => {
    declineActivity(activity._id, auth.user._id).then((response) => {
      response = response.response ? response.response : response
      if (response.status === 200) {
        setActivities(response.data.activities)
        setSuccessMessage("You Left Activity")
        setIsSuccessVisible(true)
      }
    })
  }


  return (
    isFormPopupVisible ? (
        <ActivityForm activity={activity}
          onSuccess={(activities) => {
            setActivities(activities)
            setIsFormPopupVisible(false)
            setSuccessMessage("Activity Updated")
            setIsSuccessVisible(true)
          }}
          onClose={() => setIsFormPopupVisible(false)} 
          isMyActivity={false}          
          />
      ) :
    isViewPopupVisible ? (
        <ActivityPopUp activity1={activity} onClose={(activities) => {
          setIsViewPopupVisible(false)
          if (activities) {
            setActivities(activities)
          }
        }}
        onSuccess={(activities) => {
          setActivities(activities)
          setIsViewPopupVisible(false)
        }}
        />
      ) :
    <div className="flex-grow">
      <div className="flex items-center space-x-4 mb-4">
        <div className="flex items-center space-x-2">
          <Label className="text-sm" htmlFor="date">
            Date
          </Label>
          <Input type="date" className="w-full" value={date} disabled={!filterButton} onChange={(e) => setDate(e.target.value)} />
        </div>
        <div className="flex items-center space-x-2">
          <Label className="text-sm" htmlFor="sport">
            Sport
          </Label>
          <select id="activity-name"
                className="flex h-10 w-full items-center justify-between rounded-md border border-slate-200 bg-white px-3 py-2 text-sm ring-offset-white placeholder:text-slate-500 focus:outline-none focus:ring-2 focus:ring-slate-950 focus:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50 [&>span]:line-clamp-1 dark:border-slate-800 dark:bg-slate-950 dark:ring-offset-slate-950 dark:placeholder:text-slate-400 dark:focus:ring-slate-300"
                value={sport}
                disabled={!filterButton}
                onChange={(event) => setSport(event.target.value)}>
                <option value="" disabled selected>Select Sport</option>
                {sportOptions.map((sport) => (
                  <option key={sport} value={sport}>
                    {sport}
                  </option>
                ))}
          </select>
        </div>
        <div className="flex items-center space-x-2">
          <Button className="h-9 w-36 justify-center items-center text-xs font-semibold" variant="default" onClick={handleFilter}>
            {filterButton ? ('Filter') : ('Clear Filter')}
          </Button>
        </div>
      </div>
      {isSuccessVisible && <Success message={successMessage} onClose={() => setIsSuccessVisible(false)}  children={
        <Button className="text-white hover:underline" variant="default" onClick={() => getActivities().then((response) => setActivities(response.data.activities))}>Go To MyActivity</Button>
      } />
      }
      <div className="mb-4">
          <p className="text-sm font-semibold">Click on request to join private activities</p>
        </div>
      <div className="grid gap-3 md:grid-cols-3">
        {activities.map((activity) => (
          activity.nbOfPlayers - activity.members.length > 0 &&
          <Card className="w-[300px] bg-white shadow-lg">
              <CardContent className="p-5 m-5">
                <p className="font-semibold">Title : {activity.title}</p>
                <p>Sport : {activity.sport}</p>
                <p>Date : {activity.date}</p>
                <p>Time : {activity.time}</p>
                <p>Privacy : {activity.type}</p>
              </CardContent>
              <CardFooter className="flex justify-end">
                <Button variant="default" className="m-1" onClick={() => handleViewClick(activity)}>
                      View
                </Button>
                {activity.creator._id === auth.user._id ? (
                  <>
                    <Button variant="default" className="m-1" onClick={() => handleEditClick(activity)}>
                      Edit
                    </Button>
                    <Button variant="default" className="m-1" onClick={() => handleDeletClick(activity)}>
                      Delete
                    </Button>
                  </>
                ) : activity.members.find((member) => member._id === auth.user._id) ? (
                    <Button variant="default" className="m-1" onClick={() => handleLeaveClick(activity)}>
                      Leave
                    </Button>
                ) : activity.requests.find((request) => request._id === auth.user._id) ? (
                  <Button variant="default" className="m-1" onClick={() => handleCancleClick(activity)}>
                    Cancel Request
                  </Button>
                ) : activity.type === 'Public' ? (
                  <Button variant="default" className="m-1" onClick={() => handleJoinClick(activity)}>
                    Join
                  </Button>
                ) :
                  (
                    <Button variant="outline" className="m-1" onClick={() => handleJoinClick(activity)}>
                      Request
                    </Button>
                  )}
              </CardFooter>
            </Card>
          ))}
          {
            activities.length === 0 && (
              <div className="flex justify-center items-center w-full h-96">
                <p className="text-2xl font-semibold">No Activities Found</p>
              </div>
            )
          }
      </div>
    </div>
  )
}

export default function Activities() {
  const auth = useSelector((state) => state.auth)
  return (
    <>
      {auth.isLoggedIn && auth.user !== null ? (
        <UserNav heading={`Activities`} Component={AllActivities} />
      ) : (
        <Navigate to="/" />
      )}
    </>

  )
}