import { CardTitle, CardHeader, CardContent, Card } from "../ui/card"
import { Button } from "../ui/button"
import { SelectValue, SelectTrigger, SelectItem, SelectContent, Select } from "../ui/select"
import { Label } from "../ui/label" 

import { useSelector } from "react-redux"

import { requestActivity } from "../../api/api"
import { useState } from "react"

import { joinActivity, removeActivity, declineActivity } from "../../api/api"


export default function ActivityPopUp({ onClose, activity1, onSuccess}) {
  const [activity, setActivity] = useState(activity1);
  const [players, setPlayers] = useState(activity1.members);
  const [requests, setRequests] = useState(activity1.requests);
  const auth = useSelector((state) => state.auth)

  const handleRequest = (action, id) => {
    requestActivity(activity._id, id, action).then((response) => {
      response = response.response ? response.response : response
      console.log(response)
      if(response.status === 200) {
        setActivity(response.data.activity)
        setPlayers(response.data.activity.members)
        setRequests(response.data.activity.requests)
      }
    }).catch((error) => {
      console.log(error)
    })
  }

  const handleJoinClick = (activity) => {
    joinActivity(activity._id, auth.user._id).then((response) => {
      response = response.response ? response.response : response
      if(response.status === 200) {
        onSuccess(response.data.activities)
      }
    })
  }

  const handleLeaveClick = (activity) => {
    removeActivity(activity._id, auth.user._id).then((response) => {
      response = response.response ? response.response : response
      if(response.status === 200) {
        onClose(response.data.activities)
      }
    })
  }

  const handleCancleClick = (activity) => {
    declineActivity(activity._id, auth.user._id).then((response) => {
      response = response.response ? response.response : response
      if(response.status === 200) {
        onSuccess(response.data.activities)
      }
    })
  }
  
  return (
    <Card className="w-[350px] mx-auto mt-8">
    <CardHeader>
      <div className="flex justify-between items-center">
        <CardTitle>Activity</CardTitle>
        <Button className="text-black" variant="ghost" onClick={() => onClose(null)}>
          ✕
        </Button>
      </div>
    </CardHeader>
    <CardContent>
        <div className="grid w-full gap-4">
        <div className="flex flex-col space-y-1.5">
           <p> <b> Title : </b> {activity.title} </p>
          </div>
          <div className="flex flex-col space-y-1.5">
            <p> <b>Name : </b> {activity.sport}</p>
          </div>
          <div className="flex flex-col space-y-1.5">
            <p> <b> No of players: </b> {activity.nbOfPlayers}</p>            
          </div>
          <div className="flex flex-col space-y-1.5">
            <p> <b> Privacy: </b>  {activity.type}</p>
          </div>
          <div className="flex flex-col space-y-1.5">
            <p> <b> Date  : </b> {activity.date}</p>
          </div>
          <div className="flex flex-col space-y-1.5">
            <p> <b> Time : </b> {activity.time}</p>
          </div>
          <div className="flex flex-col space-y-1.5">
            <p> <b> Description : </b> {activity.description}</p>
          </div>
          <div className="flex flex-col space-y-1.5">
           <Label htmlFor="players">Players: </Label>
              <Select>
                <SelectTrigger id="players">
                  <SelectValue placeholder="Players List" />
                </SelectTrigger>
                <SelectContent position="popper">
                  {players.map((player) => (
                    <SelectItem value={player.name}>{player.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            { activity.creator._id === auth.user._id && requests.length > 0 ?
            <div className="flex flex-col space-y-1.5">
              <Label htmlFor="requests">Requests: </Label>
              <Select>
                <SelectTrigger id="requests">
                  <SelectValue placeholder="Requests List" />
                </SelectTrigger>
                <SelectContent position="popper">
                  {requests.map((request) => (
                    <div className="flex flex-row space-y-1.5">
                        <p className="m-5">{request.name}</p>
                        <Button variant="secondary" onClick={() => handleRequest("Accept", request._id)}>Accept</Button>
                        <Button className="m-5" variant="destructive" onClick={() => handleRequest("Decline", request._id)}>Reject</Button>
                    </div>
                  ))}
                </SelectContent>
              </Select>
            </div>
            : activity.creator._id === auth.user._id ?
             <Button variant="destructive" onClick={() => onClose(null)}> Close </Button>
            : activity.members.find(member => member._id === auth.user._id)?
            <Button variant="default" className="m-1" onClick={() => handleLeaveClick(activity)}>Leave</Button>
        : activity.requests.find(member => member._id === auth.user._id)?
            <Button variant="default" className="m-1" onClick={() => handleCancleClick(activity)}>Cancel Request</Button>
        : activity.type === 'Public' ?
            <Button variant="default" onClick={() => handleJoinClick(activity)}>Join</Button> 
        : <Button variant="outline" onClick={() => handleJoinClick(activity)}>Request</Button>
        }
        </div>
    </CardContent>
  </Card>
  );
}
