import { useSelector } from "react-redux"
import { Navigate } from "react-router-dom"
import { Input } from "../ui/input"
import { useState } from "react"
import UserNav from "./UserNav"
import { Card, CardTitle, CardContent } from "../ui/card"

let filters={
    football: "c6a31d41-f49c-4f20-bde4-eba15bfe339a",
    basketball: "fc95c659-62fb-4a25-991b-11b36c29b1c6",
    volleyball: "4d69b821-15ee-48fc-be71-86b60234be43",
    tennis: "c6a31d41-f49c-4f20-bde4-eba15bfe339a",
    cricket: "1cffba3c-88e1-464e-bcc5-018c6277de17",
    badminton: "4d69b821-15ee-48fc-be71-86b60234be43",
    tableTennis: "2d2fe079-8964-4cc7-bd07-2c08b41bed03",
    swimming: "d65f10e8-4276-4b5a-91af-d1dea8cfcec2",
    running: "146da4b5-0e1f-4bc6-ae1a-ab8c46a2be33",
    cycling: "c6a31d41-f49c-4f20-bde4-eba15bfe339a",
    gym: "146da4b5-0e1f-4bc6-ae1a-ab8c46a2be33",
    yoga: "d58c218f-6129-4af6-8943-6e63bec4ffd5",
}
let sports = ["Football", "Basketball", "Volleyball", "Tennis", "Cricket", "Badminton", "Table Tennis", "Swimming", "Running", "Cycling", "Gym", "Yoga"]

function FacilityScheduleComponent() {
    let [scheduleData, setScheduleData] = useState([])
    let responseData = []
    let url = "https://rwc.gannon.edu/Facility/GetScheduleCustomAppointments?selectedId"

    let fetchData = async (date) => {
        responseData = []
        try {
            let day = new Date(date);
            let nextDay = new Date(day);
            nextDay.setDate(day.getDate() + 1);
            nextDay = nextDay.toISOString().split('T')[0]

           for (let key in filters) {
               let response = await fetch(
                   `${url}=${filters[key]}&start=${date}&end=${nextDay}`,
                   {
                       method: "GET",
                       headers: {
                           "Content-Type": "application/json",
                       },
                   })
                response = await response.json()
                responseData.push(response)
              }
              setScheduleData(responseData)
            
        } catch (error) {
            console.log(error)
        }
    }

  return (
    <div className="w-full max-w-6xl mx-auto py-8 px-4 md:px-6">
      <h1 className="text-3xl font-bold mb-6">Facility Schedule</h1>
      <div className="flex items-center justify-between mb-6">
        <Input type="date" className="auto"  onChange={(e) => fetchData(e.target.value)} />
      </div>
        <div className="grid gap-2 md:grid-cols-4">
        {scheduleData.map((data,index) => (
          <Card className="w-[200px] bg-white shadow-lg">
            <CardContent className="p-5 m-5">
             <CardTitle>{sports[index]}</CardTitle>
              <p className="font-semibold m-2">Available Slot</p>
               {data.length > 0 ? data.map((item) => (
                <>
                  {item.title !== "Busy" && (
                    <li>{new Date(item.start).getHours()}:{new Date(item.start).getMinutes()} - {new Date(item.end).getHours()}:{new Date(item.end).getMinutes()}</li>
                  )}
                </>
               )) : index === 8 || index === 10 ? <li>Full Day</li> : <p>No Schedule</p> 
                }
              </CardContent>
            </Card>
            ))}  
        </div>

    </div>
  )
}

export default function FacilitySchedule() {
    const auth = useSelector((state) => state.auth)
  return (
    <>
      {auth.isLoggedIn && auth.user !== null ? (
        <div className="flex flex-col h-screen">
          <UserNav heading={`FacilitySchedule`} Component={FacilityScheduleComponent} />
        </div>
      ) : (
        <Navigate to="/" />
      )}
    </>
  );
}