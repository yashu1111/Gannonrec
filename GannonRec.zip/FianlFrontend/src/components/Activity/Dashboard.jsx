import { useSelector } from "react-redux"
import { Navigate } from "react-router-dom"

import UserNav from "./UserNav"
import { useEffect, useState } from "react"
import ActivityPopUp from "./ActivityPopUp";
import ActivityForm from "./ActivityForm"
import Success from "./Success"
import { CardHeader, CardContent, CardFooter, Card } from "../ui/card"
import { Link } from "../ui/link"
import { Button } from "../ui/button";



import { getActivities, deleteActivity, declineActivity, removeActivity, joinActivity } from "../../api/api"



function DashbaordComponent() {

  const auth = useSelector((state) => state.auth)
  const [activities, setActivities] = useState([])
  const [isViewPopupVisible, setIsViewPopupVisible] = useState(false);
  const [activity, setActivity] = useState(null)
  const [isFormPopupVisible, setIsFormPopupVisible] = useState(false);
  const [isSuccessVisible, setIsSuccessVisible] = useState(false);
  const [successMessage, setSuccessMessage] = useState('')

  useEffect(() => {
    if (auth.isLoggedIn) {
      getActivities().then((response) => {
        response = response.response ? response.response : response
        if (response.status === 200) {
          setActivities(response.data.activities)
        }
      })
    }
  }, [auth.isLoggedIn])

  const handleDeletClick = async (activity) => {
    try {
      await deleteActivity(activity._id)
      getActivities().then((response) => {
        if (response.status === 200) {
          setActivities(response.data.activities)
          setSuccessMessage("You have Deleted Activity")
          setIsSuccessVisible(true)
        }
      })
    }
    catch (error) {
      console.log(error)
    }
  }


  const handleViewClick = (activity) => {
    setActivity(activity)
    setIsViewPopupVisible(true);
  };

  const handleEditClick = (activity) => {
    setActivity(activity)
    setIsFormPopupVisible(true);
  }

  const handleJoinClick = (activity) => {
    joinActivity(activity._id, auth.user._id).then((response) => {
      response = response.response ? response.response : response
      if (response.status === 200) {
        setActivities(response.data.activities)
        setSuccessMessage("You have Joined Activity")
        setIsSuccessVisible(true)
      }
    })
  }

  const handleLeaveClick = (activity) => {
    removeActivity(activity._id, auth.user._id).then((response) => {
      response = response.response ? response.response : response
      if (response.status === 200) {
        setActivities(response.data.activities)
        setSuccessMessage("You Left Activity")
        setIsSuccessVisible(true)
      }
    })
  }

  const handleCancleClick = (activity) => {
    declineActivity(activity._id, auth.user._id).then((response) => {
      response = response.response ? response.response : response
      if (response.status === 200) {
        setActivities(response.data.activities)
        setSuccessMessage("You Left Activity")
        setIsSuccessVisible(true)
      }
    })
  }

  function todayDate() {
    let date = new Date();
    let day = date.getDate();
    let month = date.getMonth() + 1;
    let year = date.getFullYear();
    return `${year}-${month < 10 ? `0${month}` : month}-${day < 10 ? `0${day}` : day}`;
  }

  return (
    <div className="p-5">
    {
      isFormPopupVisible ? (
        <ActivityForm activity={activity}
          onSuccess={(activities) => {
            setIsFormPopupVisible(false)
            if (activities) {
              setActivities(activities)
              setSuccessMessage(`Activity ${activity? 'Updated': 'Created'} `)
              setIsSuccessVisible(true)
            }
          }}
          onClose={() => setIsFormPopupVisible(false)}
          isMyActivity={false}
        />
      ) : 
      isViewPopupVisible ? (
        <ActivityPopUp activity1={activity} onClose={(activities) => {
          setIsViewPopupVisible(false)
          if (activities) {
            setActivities(activities)
          }
        }}
          onSuccess={(activities) => {
            setActivities(activities)
            setIsViewPopupVisible(false)
          }}
        />
      ) :
      <>
      {
        isSuccessVisible && (
          <Success onClose={() => setIsSuccessVisible(false)}  message={successMessage} children={<Link className="text-white hover:underline" href="/myactivities">Go To MyActivity</Link>} />
        )
      }
      <div className="grid gap-4 md:grid-cols-3">
      <Card>
        <CardHeader className="flex gap-2">
          <div className="text-sm font-medium">Create Activity</div>
        </CardHeader>
        <CardContent>
          {/* you can write text */}
          <p className="text-sm text-gray-500 dark:text-gray-400">Click here to create your activity and invite players</p>
        </CardContent>
        <CardFooter>
          <Button className="w-full" onClick={() => setIsFormPopupVisible(true)} >Create</Button>
        </CardFooter>
      </Card>
      <Card>
        <CardHeader className="flex gap-2">
          <div className="text-sm font-medium">Join Activities</div>
        </CardHeader>
        <CardContent>
          {/* Add comments of all activites */}
          <p className="text-sm text-gray-500 dark:text-gray-400">Click here to view activities and join</p>
        </CardContent>
        <CardFooter>
          <Link className="w-full" href="/activities">
            View and Join Activities
          </Link>
        </CardFooter>
      </Card>
      <Card>
        <CardHeader className="flex gap-2">
          <div className="text-sm font-medium">Facility Schedule</div>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-gray-500 dark:text-gray-400">Click here to view open recreation hours </p>
        </CardContent>
        <CardFooter>
          <Link className="w-full" href="/facilityschedule">
            View
          </Link>
        </CardFooter>
      </Card>
    
      </div>
      <div className="m-5 border-t-2 border-red-200">
        <div className="text-xl font-medium m-2">Today Activities</div>
          <div className="grid gap-4 md:grid-cols-3">
          { 
          activities.map((activity) => (
            activity.date === todayDate() &&
            activity.nbOfPlayers - activity.members.length > 0 &&
            <Card className="w-[300px] bg-white shadow-lg">
              <CardContent className="p-5 m-5">
                <p className="font-semibold">Title : {activity.title}</p>
                <p>Sport : {activity.sport}</p>
                <p>Date : {activity.date}</p>
                <p>Time : {activity.time}</p>
                <p>Privacy : {activity.type}</p>
              </CardContent>
              <CardFooter className="flex justify-end">
                {activity.creator._id === auth.user._id ? (
                  <>
                    <Button variant="default" className="m-1" onClick={() => handleViewClick(activity)}>
                      View
                    </Button>
                    <Button variant="default" className="m-1" onClick={() => handleEditClick(activity)}>
                      Edit
                    </Button>
                    <Button variant="default" className="m-1" onClick={() => handleDeletClick(activity)}>
                      Delete
                    </Button>
                  </>
                ) : activity.members.find((member) => member._id === auth.user._id) ? (
                  <>
                    <Button variant="default" className="m-1" onClick={() => handleViewClick(activity)}>
                      View
                    </Button>
                    <Button variant="default" className="m-1" onClick={() => handleLeaveClick(activity)}>
                      Leave
                    </Button>
                  </>
                ) : activity.requests.find((request) => request._id === auth.user._id) ? (
                  <Button variant="default" className="m-1" onClick={() => handleCancleClick(activity)}>
                    Cancel Request
                  </Button>
                ) : activity.type === 'Public' ? (
                  <Button variant="default" className="m-1" onClick={() => handleJoinClick(activity)}>
                    Join
                  </Button>
                ) :
                  (
                    <Button variant="outline" className="m-1" onClick={() => handleJoinClick(activity)}>
                      Request
                    </Button>
                  )}
              </CardFooter>
            </Card>
          ))}
          </div>
      </div>
    </>
    }
    </div>
  )
}

export default function Dashboard() {

  const auth = useSelector((state) => state.auth)
  return (
    <>
      {auth.isLoggedIn && auth.user !== null ? (
        <div className="flex flex-col h-screen">
          <UserNav heading={`Dashboard`} Component={DashbaordComponent} />
        </div>
      ) : (
        <Navigate to="/" />
      )}
    </>

  )
}