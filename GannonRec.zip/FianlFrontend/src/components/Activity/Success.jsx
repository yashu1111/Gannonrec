import { Button } from '../ui/button';

export default function Success({onClose, message, children}) {
  return (
    <div className="bg-green-500 rounded-lg p-4 m-2 flex items-center space-x-3">
      <Button className="text-black" variant="outline" onClick={onClose}>
            ✕
      </Button>
      <div>
        <h3 className="text-lg font-medium text-white">Success! : {message} <> </>
        {children}
        </h3>
      </div>
    </div>
  )
}

