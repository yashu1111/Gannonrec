import { CardContent, CardFooter, Card } from "../ui/card"
import { Button } from "../ui/button"

import UserNav from "./UserNav"
import ActivityPopUp from "./ActivityPopUp";
import ActivityForm from "./ActivityForm"

import { useState, useEffect } from "react";


import { useSelector } from "react-redux"
import { Navigate } from "react-router-dom"

import  {activitiesByUser, deleteActivity, declineActivity, removeActivity } from "../../api/api"

import Success from "./Success";



function Activities(){
    const [isViewPopupVisible, setIsViewPopupVisible] = useState(false);
    const [isFormPopupVisible, setIsFormPopupVisible] = useState(false);
    const [activities, setActivities] = useState([])
    const [activity, setActivity] = useState(null)
    const [isSuccessVisible, setIsSuccessVisible] = useState(false);
    const [successMessage, setSuccessMessage] = useState('')

    const auth = useSelector((state) => state.auth)

   useEffect(() => {
    if(auth.isLoggedIn) {
      activitiesByUser(auth.user._id).then((response) => {
        response = response.response ? response.response : response
        if(response.status === 200) {
          setActivities(response.data.activities)
        }
      })
    }
  }, [auth])
    
    const handleDeletClick = async (activity) => {  
      try{  
        deleteActivity(activity._id).then((response) => {
          if(response.status === 200) {
            activitiesByUser(auth.user._id).then((response) => {
              response = response.response ? response.response : response
              if(response.status === 200) {
                setActivities(response.data.activities)
                setSuccessMessage("You have Deleted Activity")
                setIsSuccessVisible(true)
              }
            })
            setSuccessMessage("You have Deleted Activity")
            setIsSuccessVisible(true)
          }
        })
      }
      catch (error) {
        console.log(error)
      }
    }
      

    const handleViewClick = (activity) => {
      setActivity(activity)
      setIsViewPopupVisible(true);
    };

    const handleEditClick = (activity) => {
      setActivity(activity)
      setIsFormPopupVisible(true);
    }

    const handleNewClick = () => {
      setActivity(null)
      setIsFormPopupVisible(true);
    }

    const handleLeaveClick = (activity) => {
      removeActivity(activity._id, auth.user._id).then((response) => {
        if(response.status === 200) {
          activitiesByUser(auth.user._id).then((response) => {
            response = response.response ? response.response : response
            if(response.status === 200) {
              setActivities(response.data.activities)
            }
          })
          setSuccessMessage("You Left Activity")
          setIsSuccessVisible(true)
        }
      })
    }
  
    const handleCancleClick = (activity) => {
      declineActivity(activity._id, auth.user._id).then((response) => {
        if(response.status === 200) {
          activitiesByUser(auth.user._id).then((response) => {
            response = response.response ? response.response : response
            if(response.status === 200) {
              setActivities(response.data.activities)
            }
          })
          setSuccessMessage("You Left Activity")
          setIsSuccessVisible(true)
        }
      }
    )}
      return (
        isFormPopupVisible ? 
            <ActivityForm activity={activity} onSuccess={(activities) => {
              setIsFormPopupVisible(false)
              setActivities(activities)
              setSuccessMessage("Activity " + (activity ? "Updated" : "Created"))
              setIsSuccessVisible(true)
            }}
            onClose={() => setIsFormPopupVisible(false)} 
            isMyActivity={true}            
            />
        : 
        isViewPopupVisible ?
          <ActivityPopUp activity1={activity} onClose={() => setIsViewPopupVisible(false)} />
        :
        <>
          {isSuccessVisible && <Success message={successMessage} onClose={() => setIsSuccessVisible(false)} />}
            <div className="flex-grow">
              <div className="grid gap-3 md:grid-cols-3">
                <Card className="w-[300px] bg-white shadow-lg" onClick={handleNewClick}>
                  <CardContent className="p-5 m-5 flex justify-center items-center">
                    <h1 className="font-bold text-7xl">+</h1>
                  </CardContent>
                </Card>
                {activities.length > 0 &&
                  activities.map((activity) => (
                    <Card className="w-[300px] bg-white shadow-lg">
                      <CardContent className="p-5 m-5">
                        <p className="font-semibold">Title : {activity.title}</p>
                        <p>Sport : {activity.sport}</p>
                        <p>Date : {activity.date}</p>
                        <p>Time : {activity.time}</p>
                        <p>Privacy : {activity.type}</p>
                      </CardContent>
                      <CardFooter className="flex justify-end">
                        {activity.creator._id === auth.user._id ? (
                          <>
                            <Button variant="default" className="m-1" onClick={() => handleViewClick(activity)}>
                              View
                            </Button>
                            <Button variant="default" className="m-1" onClick={() => handleEditClick(activity)}>
                              Edit
                            </Button>
                            <Button variant="default" className="m-1" onClick={() => handleDeletClick(activity)}>
                              Delete
                            </Button>
                          </>
                        ) : activity.members.find((member) => member._id === auth.user._id) ? (
                          <>
                            <Button variant="default" className="m-1" onClick={() => handleViewClick(activity)}>
                              View
                            </Button>
                            <Button variant="default" className="m-1" onClick={() => handleLeaveClick(activity)}>
                              Leave
                            </Button>
                          </>
                        ) : (
                          <Button variant="outline" className="m-1" onClick={() => handleCancleClick(activity)}>
                            Cancel Request
                          </Button>
                        )}
                      </CardFooter>
                    </Card>
                  ))}
              </div>
            </div>
        </>
  )
}

export default function MyActivity(){
  const auth = useSelector((state) => state.auth)
  return(
    <>
        {auth.isLoggedIn && auth.user !== null ? (
          <UserNav heading={`My Activity`} Component={Activities} />
        ) : (
          <Navigate to="/" />
        )}    
    </>

  )
}