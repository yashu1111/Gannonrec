import React from 'react';
import { Link } from "../ui/link";
import { useSelector, useDispatch } from "react-redux";
import { logout } from "../../store/authSlice";

import { Navigate } from "react-router-dom";

function UserNav({ heading, Component }) {
  const auth = useSelector((state) => state.auth);

  const dispatch = useDispatch();

  // Handler for logout action
  const handleLogout = () => {
    dispatch(logout());
  };

  return (
    auth.isLoggedIn && auth.user !== null ?
    <div className="flex flex-col md:flex-row h-screen">
        <aside className="w-full md:w-64 bg-[#bd1e59] p-5 md:fixed md:h-screen">
          <div className="flex items-center space-x-2 mb-5">
            <Link href="/" variant="unstyled">
              <img
                alt="Logo"
                src="https://images.squarespace-cdn.com/content/v1/5d48a985b59b1600014c7794/1574396720383-3LECB7ZYTXMZHL3TQ59R/LogoRayBelieve_300.png"
                className="h-10"
                style={{ aspectRatio: "auto 90 / 50", objectFit: "cover" }}
              />
            </Link>
          </div>
          <nav className="flex flex-col space-y-8 m-50">
          <Link className="text-white hover:underline" href="/"> Dashboard </Link>
            <Link className="text-white hover:underline" href="/activities">Activities</Link>
            <Link className="text-white hover:underline" href="/myactivities">My Activity</Link>
            <Link className="text-white hover:underline" href="/account">Manage Account</Link>
            <Link className="text-white hover:underline" href="/about">About Us</Link>
            <Link className="text-white hover:underline" href="/facilityschedule">Facility Schedule</Link>
          </nav>
        </aside>
        <main className="flex-1 ml-64">
          <header className="flex justify-between items-center p-5 bg-[#f4aa3e]">
            <div className="p-4 flex justify-center">
              <span className="text-white font-bold">{heading}</span>
            </div>
            <div className="p-4 text-center">
              <span className="text-white">Welcome {auth.isLoggedIn ? auth.user.name : "Guest"}</span>
            </div>
            <div className="flex items-center space-x-4">
              <Link className="text-white hover:underline" href="#" onClick={handleLogout}>
                Logout
              </Link>
            </div>
          </header>
          <section className="p-5">
            {Component ? <Component /> : null}
          </section>
        </main>
    </div>
    : <Navigate to="/" />
  );
}


export default UserNav;
