import Navbar from "./Nav";
import ImageCarousel from "./ImageCarousel";

function Home() {
  return (
    <div className="h-screen" style={{ backgroundColor: '#f7e8d1' }}>
      <Navbar />
      <main className="container mx-auto px-4 py-8">
        <div className="flex flex-col lg:flex-row items-center justify-between space-y-4 lg:space-y-0 lg:space-x-8">
          <div className="lg:w-1/2">
            <div className="h-96 lg:h-auto">
              <ImageCarousel className="image-carousel" />
            </div>
          </div>
          <div className="space-y-4 lg:w-1/2">
            <div className="text-center lg:text-left">
              <p className="text-lg">
                Welcome to GannonRecConnect, the go-to hub for Gannon University students seeking play partners for
                recreational activities. Whether you're into sports, fitness, or casual games, this platform is designed
                to help you connect with like-minded enthusiasts ready to join in the fun.
              </p>
            </div>
            <div className="flex justify-center lg:justify-start space-x-4">
              <a href="/login" className="bg-blue-500 text-white font-bold py-2 px-4 rounded hover:bg-blue-700 mr-4">Login</a>
              <a href='/signup' className="bg-green-500 text-white font-bold py-2 px-4 rounded hover:bg-green-700">Sign Up</a>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}

export default Home;
