import {useState} from 'react';
import Navbar from './Nav';
import { Button } from './ui/button';
import {Link} from './ui/link';
import Verify from './Verify';

import { useSelector, useDispatch } from 'react-redux';
import { userRegister } from '../api/api';
import { login } from '../store/authSlice';
import { Navigate } from 'react-router-dom'
import { set } from 'date-fns';



export default function Signup() {

  const [name, setName] = useState('');
  const [nameError, setNameError] = useState('');
  const [email, setEmail] = useState('');
  const [emailError, setEmailError] = useState('');
  const [retypeEmail, setRetypeEmail] = useState('');
  const [retypeEmailError, setRetypeEmailError] = useState('');
  const [password, setPassword] = useState(''); 
  const [passwordError, setPasswordError] = useState('');
  const [retypePassword, setRetypePassword] = useState('');
  const [retypePasswordError, setRetypePasswordError] = useState('');
  const [verifyPopup, setVerifyPopup] = useState(false);

  const [error, setError] = useState(null);

  const auth = useSelector((state) => state.auth);
  const dispatch = useDispatch();


  const validateEmail = () => {
    if (!email) {
      setEmailError('Email is required');
      return false;
    }
    else if (!/\S+@+\S+\.\S+/.test(email)) {
      setEmailError('Email is invalid');
      return false;
    }
    // else if (!/\S+@gannon.edu+/.test(email)) {
    //   setEmailError('Email is invalid or not a Gannon email');
    //   return;
    // }
    setEmailError('');
    return true;
  }

  const validateRetypeEmail = () => {
    if (!retypeEmail) {
      setRetypeEmailError('Retype email is required');
      return false;
    }
    else if (retypeEmail !== email) {
      setRetypeEmailError('Emails do not match');
      return false;
    }
    setRetypeEmailError('');
    return true;
  }

  const validatePassword = () => {
    if (!password) {
      setPasswordError('Password is required');
      return false;
    }
    else if (password.length < 6) {
      setPasswordError('Password must be at least 6 characters');
      return false;
    }
    setPasswordError('');
    return true;
  }
  

  const validateName = () => {
    if (!name) {
      setNameError('Name is required');
      return false;
    }
    else if (name.length < 3) {
      setNameError('Name must be at least 3 characters');
      return false;
    }
    setNameError('');
    return true;
  }

  const validateRetypePassword = () => {
    if (!retypePassword) {
      setRetypePasswordError('Retype password is required');
      return false;
    }
    else if (retypePassword !== password) {
      setRetypePasswordError('Passwords do not match');
      return false;
    }
    setRetypePasswordError('');
    return true;
  }

  const validateForm = () => {
    const isNameValid = validateName();
    const isEmailValid = validateEmail();
    const isRetypeEmailValid = validateRetypeEmail();
    const isPasswordValid = validatePassword();
    const isRetypePasswordValid = validateRetypePassword();
    return isNameValid && isEmailValid && isRetypeEmailValid && isPasswordValid && isRetypePasswordValid;
  }
 
  const handleSubmit = async (e) => {
    setError(null);
    e.preventDefault();
    const isFormValid = validateForm();
    if (isFormValid) {   
      try {
        const response = await userRegister(name, email, password);
        if (response.success) {
          setVerifyPopup(true);
        }
        else {
          setError(response.data.message);
        }
      }
      catch (error) {
        console.log(error);
      }
    }
  }

  return (
    <>
    {auth.isLoggedIn && auth.user !== null ? <Navigate to="/" /> :
    <div>
      <Navbar />
      {verifyPopup ? 
      <Verify 
        email={email} 
        onClose={() => setVerifyPopup(false)}
        onSuccessfulVerification={(user) => {
          dispatch(login(user));
          setVerifyPopup(false);
        }}      
      /> :
    <div className="flex h-screen bg-gray-100">
      <div className="flex flex-col w-1/2 p-12 space-y-6 bg-[#f7e8d1]">
        <h1 className="text-4xl font-bold text-[#bd1e59]">Gannon University</h1>
        <div className="space-y-4">
          <div className="flex items-center">
            <CloudLightningIcon className="text-[#facc15] h-6 w-6" />
            <p className="ml-2 text-lg text-gray-700">
              Discover & Join Activities: Find volleyball, badminton, and more. There's something for everyone!
            </p>
          </div>
          <div className="flex items-center">
            <UsersIcon className="text-[#34d399] h-6 w-6" />
            <p className="ml-2 text-lg text-gray-700">
              Meet New Play Partners: Connect with students who share your interests and passion for sports and
              recreational activities.
            </p>
          </div>
          <div className="flex items-center">
            <HeartIcon className="text-[#ef4444] h-6 w-6" />
            <p className="ml-2 text-lg text-gray-700">
              Enhance Your University Life: Join a vibrant community that promotes a healthy, active, and social
              lifestyle on campus.
            </p>
          </div>
        </div>
      </div>
      <div className="flex flex-col w-1/2 p-12 space-y-6 bg-white">
        <h2 className="text-3xl font-semibold">Sign Up and Start Connecting with Fellow Recreational Enthusiasts</h2>
        <form className="space-y-4" onSubmit={handleSubmit}>
          <div className="flex space-x-4">
            <Input placeholder="Name" type="text" onChange={(e) => setName(e.target.value)}/>
            <span className="text-red-500 text-sm">{nameError}</span>
          </div>
          <div className="flex space-x-4">
            <Input placeholder="Email" type="email" onChange={(e) => setEmail(e.target.value)} />
            <span className="text-red-500 text-sm">{emailError}</span>
          </div>
          <div className="flex space-x-4">
            <Input placeholder="Re-type Email" type="email" onChange={(e) => setRetypeEmail(e.target.value)} />
            <span className="text-red-500 text-sm">{retypeEmailError}</span>
          </div>
          <div className="flex space-x-4">
            <Input placeholder="Password" type="password" onChange={(e) => setPassword(e.target.value)} />
            <span className="text-red-500 text-sm">{passwordError}</span>
          </div>
          <div className="flex space-x-4">
            <Input placeholder="Re-type password" type="password" onChange={(e) => setRetypePassword(e.target.value)} />
            <span className="text-red-500 text-sm">{retypePasswordError}</span>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-sm text-red-600">{error}</span>
          </div>
          <div className="flex space-x-4">
            <Button className="bg-[#facc15] text-white font-bold py-2 px-4 rounded hover:bg-blue-700" onClick={handleSubmit} >Sign Up</Button>
          </div>
          <div className="space-x-4">
            Already have an account?
            <Link variant="link" href="/login" className="text-indigo-600 hover:underline">
              Login here.
            </Link>
          </div>
        </form>
      </div>
    </div>
    }
    </div>
    }
    </>
  )
}

const Input = ({ type = "text", placeholder = "", ...props }) => (
  <input
    type={type}
    placeholder={placeholder}
    className="border border-gray-300 p-2 m-2 rounded-md focus:outline-none focus:border-blue-500"
    {...props}
  />
);


function CloudLightningIcon(props) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M6 16.326A7 7 0 1 1 15.71 8h1.79a4.5 4.5 0 0 1 .5 8.973" />
      <path d="m13 12-3 5h4l-3 5" />
    </svg>
  )
}


function HeartIcon(props) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z" />
    </svg>
  )
}


function UsersIcon(props) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" />
      <circle cx="9" cy="7" r="4" />
      <path d="M22 21v-2a4 4 0 0 0-3-3.87" />
      <path d="M16 3.13a4 4 0 0 1 0 7.75" />
    </svg>
  )
}
