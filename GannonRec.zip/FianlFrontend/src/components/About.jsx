import React from "react";
import Navbar from "./Nav";
import UserNav from "./Activity/UserNav";

import { useSelector } from "react-redux";

function AboutUS() {
  const isLoggedIn = useSelector((state) => state.auth.isLoggedIn);
  return (
    <div style={{ backgroundColor: '#f7e8d1' , minHeight: '100vh'}}>
      {!isLoggedIn && <Navbar />}
      {/* <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12"> */}
        <h1 className="text-4xl font-bold text-center mb-10">
          Connecting Gannon Students Through Recreational Activities
        </h1>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <img
            alt="Table Tennis"
            className="rounded"
            height="200"
            src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSLEPceq8PJW1JMxLr4VWl2uPNm51LP0tiScw&s"
            style={{
              aspectRatio: "300/200",
              objectFit: "cover",
            }}
            width="300"
          />
          <div>
            <h2 className="text-2xl font-semibold mb-4">Our Mission:</h2>
            <p>
              "At GannonRecConnect, our mission is to foster a vibrant and inclusive community by connecting students
              through a variety of recreational activities. We aim to enhance the university experience by making it
              easier for everyone to find and participate in activities they love, meet new people, and stay active and
              healthy."
            </p>
          </div>
          <img
            alt="Tennis"
            className="rounded"
            height="200"
            src="https://toc.h-cdn.co/assets/16/30/2560x1920/sd-aspect-1469562775-gettyimages-452846870.jpg"
            style={{
              aspectRatio: "300/200",
              objectFit: "cover",
            }}
            width="300"
          />
          <div>
            <h2 className="text-2xl font-semibold mb-4">Our Vision:</h2>
            <p>
              "We envision a campus where every student feels connected, engaged, and part of a dynamic community.
              Through GannonRecConnect, we strive to break down barriers to participation in recreational activities,
              ensuring every student has the opportunity to explore new interests and forge lasting friendships."
            </p>
          </div>
          <img
            alt="Volleyball"
            className="rounded"
            height="200"
            src="https://img.olympics.com/images/image/private/t_s_w960/t_s_16_9_g_auto/f_auto/v1536936974/primary/exvzqcvorticinejmmel"
            style={{
              aspectRatio: "300/200",
              objectFit: "cover",
            }}
            width="300"
          />
          <div>
            <h2 className="text-2xl font-semibold mb-4">Why GannonRecConnect?</h2>
            <p>
              <strong>Community Building:</strong>
              We believe in the power of sports and recreational activities to bring people together, creating a sense of
              belonging and community spirit among students.{"\n              "}
            </p>
            <p>
              <strong>Ease of Access:</strong>
              With our platform, finding, joining, or organizing a game has never been easier. Whether you're a
              competitive athlete or looking for a casual meet-up, GannonRecConnect is your gateway to a world of
              activities.{"\n              "}
            </p>
            <p>
              <strong>Promoting Wellness:</strong>
              Engaging in physical activities is crucial for mental and physical health. GannonRecConnect encourages an
              active lifestyle, contributing to the overall well-being of our students.{"\n              "}
            </p>
          </div>
          <img
            alt="Soccer"
            className="rounded"
            height="200"
            src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRrWBGUNEk8DsstDdL6laae3ISX1gsWgqddrA&s"
            style={{
              aspectRatio: "300/200",
              objectFit: "cover",
            }}
            width="300"
          />
          <div>
            <h2 className="text-2xl font-semibold mb-4">Meet the Team:</h2>
            <p>
              "Our team is made up of passionate individuals dedicated to enhancing student life at Gannon University.
              From tech enthusiasts to sports aficionados, we bring diverse skills and experiences to the table, united by
              a common goal: to make GannonRecConnect a welcoming, inclusive, and vibrant platform for all."
            </p>
          </div>
        </div>
    </div>
  );
}



export default function About() {
  const auth = useSelector((state) => state.auth);
  return (
    <>
      {auth.isLoggedIn && auth.user !== null ? <UserNav heading="About Us" Component={AboutUS} /> : <AboutUS />}
    </>
  );
}
