import React, { useState, useEffect } from 'react';

// Placeholder array for image URLs
const images = [
  'https://gannonknight.com/wp-content/uploads/2021/04/gannon-arch-photo-revised-900x600.jpg',
  'https://rwc.gannon.edu/Themes/SitemapImages/Front.png',
  'https://campaign.gannon.edu/assets/ContentLayoutImages/content-athletics-1-v2.jpg',
  // Add as many images as you have
];

function ImageCarousel() {
    const [currentIndex, setCurrentIndex] = useState(0);

    // Function to go to the next slide
    const nextSlide = () => {
      setCurrentIndex((prevIndex) => (prevIndex + 1) % images.length);
    };
  
    // Set up an interval to go to the next slide every 3 seconds
    useEffect(() => {
      const interval = setInterval(nextSlide, 3000);
  
      // Clear the interval on unmount
      return () => clearInterval(interval);
    }, []);
  
    return (
      <div className="relative">
        {/* Carousel image */}
        <div className= "h-96 w-full overflow-hidden rounded-lg">
          <img src={images[currentIndex]} alt={'Slide ' + currentIndex} className="object-contain md:object-scale-down" />
        </div>
  
        {/* Carousel Dots */}
        <div className="absolute bottom-0 left-1/2 transform -translate-x-1/2 flex space-x-2">
          {images.map((_, index) => (
            <span
              key={index}
              className={`inline-block h-3 w-3 rounded-full ${index === currentIndex ? 'bg-white' : 'bg-gray-400'}`}
              onClick={() => setCurrentIndex(index)}
            ></span>
          ))}
        </div>
      </div>
    );
  };  

export default ImageCarousel;
