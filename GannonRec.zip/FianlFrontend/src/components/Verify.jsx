import { CardTitle, CardHeader, CardContent, CardFooter, Card } from "./ui/card"
import { Button } from "./ui/button"
import { Label } from "./ui/label"
import { Input } from "./ui/input"
import { useState } from "react"
import { useSelector } from "react-redux"
import { verifyOtp, resendOtp } from "../api/api"
import { set } from "date-fns"

export default function Verify({onClose, email , onSuccessfulVerification}) {

  const [Otp, setOtp] = useState("")
  const [OtpError, setOtpError] = useState("")
  const [resendMessage, setResendMessage] = useState("")

  const auth = useSelector((state) => state.auth)

  const handleVerify = async () => {
    if (!Otp) {
      setOtpError("OTP is required")
      return
    }
    setOtpError("")
    await verifyOtp(email, Otp).then((response) => {
      response = response.response ? response.response : response
      if (response.data.user) {
        onSuccessfulVerification(response.data.user)
      }
      else {
        setOtpError(response.data.message)
      }
      
    })
  }

  const handleResend = async () => {
    setOtpError("")
    await resendOtp(email).then((response) => {
      response = response.response ? response.response : response
      if (response.data.success) {
        setResendMessage(response.data.success)
      }
      else {
        setResendMessage(response.data.error)
      }
      
    })
  }

  return (
    <Card className="w-[500px] mx-auto mt-8">
      <CardHeader>
        <div className="flex justify-between items-center">
          <CardTitle>Verify OTP</CardTitle>
          <Button className="text-black" variant="ghost" onClick={() => onClose()}>
            ✕
          </Button>
        </div>
      </CardHeader>
      <CardContent>
            <div className="flex flex-col space-y-1.5">
              <Label htmlFor="otp">Enter OTP sent to {email}</Label>
              <Input id="otp" placeholder="Enter OTP" value={Otp} onChange={(event) => setOtp(event.target.value)} />
              <span className="text-red-500">{OtpError}</span>
              {resendMessage !== "" && <span className="text-green-500 text-sm">{resendMessage}</span>}
            </div>
      </CardContent>
      <CardFooter className="flex justify-center">
        <Button className="w-full m-2" onClick={handleVerify}> Verify </Button>
        <Button className="w-full m-2" onClick={handleResend}> Resend OTP </Button>
      </CardFooter>
    </Card>
  )
}
