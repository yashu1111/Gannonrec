import { CardTitle, CardDescription, CardHeader, CardContent, CardFooter, Card } from "./ui/card"
import { Label } from "./ui/label"
import { Input } from "./ui/input"
import { Button } from "./ui/button"
import { Link } from "./ui/link"

export default function ForgotPassword() {
  return (
    <Card className="mx-auto max-w-sm">
      <CardHeader className="space-y-1">
        <CardTitle className="text-2xl font-bold">Forgot password</CardTitle>
        <CardDescription>Enter your email below to reset your password</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="email">Email</Label>
          <Input id="email" placeholder="m@example.com" type="email" />
        </div>
        <Button className="w-full" type="submit">
          Submit
        </Button>
      </CardContent>
      <CardFooter>
        <Link className="text-sm underline" href="#">
          Back to login
        </Link>
      </CardFooter>
    </Card>
  )
}
