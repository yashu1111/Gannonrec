// CURD API

import axios from 'axios';

const API_URL = 'https://gannonrec.site/api';
// const API_URL = 'http://localhost:3001/api';

export const userLogin = async (email, password) => {
  try {
    const response = await axios.post(`${API_URL}/users/login`, {
      email,
      password,
    });
    return response.data;
  } catch (error) {
    return error.response;
  }
};

export const userRegister = async ( name, email, password) => {
    try {
        const response = await axios.post(`${API_URL}/users/signup`, {
        name,
        email,
        password,
        });
        return response.data;
    } catch (error) {
        return error.response;
    }
};

export const updateUser = async (id, data) => {
    try {
        const response = await axios.put(`${API_URL}/users/${id}`, data);
        return response;
    } catch (error) {
        return error.response;
    }
};


// get all activities
export const getActivities = async () => {
    try {
        const response = await axios.get(`${API_URL}/activity`);
        return response;
    } catch (error) {
        return error;
    }
};

// get activity by id
export const getactivity = async (id) => {
    try {
        const response = await axios.get(`${API_URL}/activity/${id}`);
        return response;
    } catch (error) {
        return error;
    }
};

// get activities by user id

export const activitiesByUser = async (id) => {
    try {
        const response = await axios.get(`${API_URL}/activity/user/${id}`);
        return response;
    } catch (error) {
        return error;
    }
}

// create activity

export const createActivity = async (userID, data) => {
    try {
        await axios.post(`${API_URL}/activity`,data);
        const response = await axios.get(`${API_URL}/activity/user/${userID}`);
        return response.data.activities;        
    } catch (error) {
        return error;
    }
}

// update activity

export const updateActivity = async (id, userID, data) => { 
    try {
        await axios.put(`${API_URL}/activity/${id}`, data);
        const response = userID ? await axios.get(`${API_URL}/activity/user/${userID}`) : await axios.get(`${API_URL}/activity`);
        return response.data.activities;
    } catch (error) {
        return error;
    }
}

// delete activity

export const deleteActivity = async (id) => {
    try {
        const response = await axios.delete(`${API_URL}/activity/${id}`);
        return response;
    } catch (error) {
        return error;
    }
}

// join activity

export const joinActivity = async (id, userID) => {
    try {
        await axios.post(`${API_URL}/activity/join/`,
        {userId: userID, activityId: id});
        const response = await axios.get(`${API_URL}/activity`);
        return response;
    } catch (error) {
        return error;
    }
}

// leave activity

export const removeActivity = async (id, userID) => {
    try {
        await axios.post(`${API_URL}/activity/remove/`, 
        {userId: userID, activityId: id});
        const response = await axios.get(`${API_URL}/activity`);
        return response;
    } catch (error) {
        return error;
    }
}

// request activity

export const requestActivity = async (id, userID, type) => {
    try {
        await axios.post(`${API_URL}/activity/request/`, 
        {userId: userID, activityId: id, type: type});  
        const response = await axios.get(`${API_URL}/activity/${id}`);
        return response;
    } catch (error) {
        return error;
    }
}

// decline activity

export const declineActivity = async (id, userID) => {
    try {
        await axios.post(`${API_URL}/activity/decline/`, 
        {userId: userID, activityId: id});
        const response = await axios.get(`${API_URL}/activity`);
        return response;
    } catch (error) {
        return error;
    }
}


// forgot password

export const forgotPassword = async (email) => {
    try {
        const response = await axios.post(`${API_URL}/users/forgot-password`, 
        {email: email});
        return response;
    } catch (error) {
        return error;
    }
}

// verifyOtp

export const verifyOtp = async (email, otp) => {
    try {
        const response = await axios.post(`${API_URL}/users/verify`, 
        {email: email, otp: otp});
        return response;
    } catch (error) {
        return error;
    }
}

// resend verification

export const resendOtp = async (email) => {
    try {
        const response = await axios.post(`${API_URL}/users/resend-verification`, 
        {email: email});
        return response;
    } catch (error) {
        return error;
    }
}