import { configureStore } from '@reduxjs/toolkit';
import authReducer from './authSlice';
import storage from 'redux-persist/lib/storage';
import { persistReducer, persistStore } from 'redux-persist';
import {thunk} from 'redux-thunk';

const persistedReducer = persistReducer({ key: 'auth', storage }, authReducer);

export const store = configureStore({
    reducer: { auth: persistedReducer },
    middleware:  (getDefaultMiddleware) => [...getDefaultMiddleware(), thunk]
})

export const persistor = persistStore(store);
