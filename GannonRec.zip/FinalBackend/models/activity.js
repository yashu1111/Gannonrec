const mongoose = require('mongoose');

const Schema = mongoose.Schema;

const activitySchema = Schema({
    title: { type: String, required: true },
    sport: { type: String, required: true },
    date: { type: String, required: true },
    time: { type: String, required: true },
    nbOfPlayers: { type: Number, required: true },
    description: { type: String, required: true },
    type: { type: String, enum: ["Public", "Private"], default: "Public" },
    creator: { type: Schema.Types.ObjectId, ref: 'User' },
    members: [{ type: Schema.Types.ObjectId, ref: 'User' }],
    requests: [{ type: Schema.Types.ObjectId, ref: 'User' }],
});

module.exports = mongoose.model('Activity', activitySchema);

