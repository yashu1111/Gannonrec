const express = require('express');

const { check } = require('express-validator');

const activityControllers = require('../controllers/activity-controllers');

const router = express.Router();

router.post('/', [
    check('title').notEmpty(),
    check('sport').notEmpty(),
    check('date').notEmpty(),
    check('nbOfPlayers').notEmpty(),
    check('description').isLength({ min: 5 }),
    check('type').isIn(['Public', 'Private'])
], activityControllers.createActivity);

router.get('/', activityControllers.getActivities);
router.get('/user/:uid', activityControllers.getActivitiesOfUser);
router.get('/:id', activityControllers.getActivityById);
router.put('/:id', activityControllers.updateActivityById);
router.delete('/:id', activityControllers.deleteActivityById);

router.post('/join/', [
    check('activityId').notEmpty(),
    check('userId').notEmpty()
], activityControllers.joinActivity);

router.post('/decline/', [
    check('activityId').notEmpty(),
    check('userId').notEmpty()
], activityControllers.declineActivity);

router.post('/request/', [
    check('activityId').notEmpty(),
    check('userId').notEmpty(),
    check('type').isIn(['Accept', 'Decline'])
], activityControllers.requestActivity);

router.post('/remove/', [
    check('activityId').notEmpty(),
    check('userId').notEmpty()
], activityControllers.removeUser);

module.exports = router;

