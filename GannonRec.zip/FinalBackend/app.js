const express = require('express');
const cors = require('cors');

const activityRoutes = require('./routes/activity-routes');
const usersRoutes = require("./routes/users-routes");
const mongoose = require('mongoose');

const app = express();
app.use(cors())
app.use(express.json())
app.use(express.urlencoded({extended: false}))
app.use(express.static('public'))


app.use('/api/activity', activityRoutes);
app.use("/api/users", usersRoutes);


app.use((error, req, res, next) => {

    if (res.headerSent) {
        return next(error);
    }
    res.status(error.code || 500);
    res.json({ message: error.message || 'An unknown error occured' });

});


const url = "mongodb+srv://Yash:Mongo1999@cluster0.cqtftzk.mongodb.net/rec-connect-db";
mongoose.connect(url).then(() => {
    console.log("connected to mongodb")
    app.listen(3001);
    console.log("server is running on localhost:3001")
}).catch(err => {
    console.log(err);
});