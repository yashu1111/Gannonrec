// const { validationResult } = require('express-validator');

const User = require("../models/user");

const nodemailer = require("nodemailer");

const randomToken = () => {
  return Math.floor(100000 + Math.random() * 900000);
};

const transporter = nodemailer.createTransport({
  service: "Gmail",
  host: "smtp.gmail.com",
  port: 465,
  secure: true,
  auth: {
    user: "gannonrecconnect@gmail.com",
    pass: "cavs roej pbwq zhvw",
  },
});

const sendEmail = async (email, subject, text) => {
  try {
    await transporter.sendMail({
      from: '"no-reply Gannon Rec Center <gannonrecconnect@gmail.com>',
      to: email,
      subject: subject,
      text: text,
    });
  } catch (error) {
    console.error("Error sending email: ", error);
  }
};

const signup = async (req, res, next) => {
  const { name, email, password } = req.body;
  let existingUser;
  try {
    existingUser = await User.findOne({ email: email });
  } catch (err) {
    return res
      .status(500)
      .json({ message: "Signup failed, please try again later" });
  }
  if (existingUser) {
    return res.status(422).json({ message: "User Email already exists" });
  }

  const token = randomToken();

  const createdUser = new User({
    name: name,
    email: email,
    password: password,
    verficationToken: token,
  });

  console.log(createdUser);

  try {
    await createdUser.save();
  } catch (err) {
    return res.status(500).json({ message: err.message });
  }

  const text = `Your verification token is ${token}`;

  sendEmail(email, "Verification for Gannon Rec Center", text);

  res.status(201).json({ success: "User created please Verify" });
};

const login = async (req, res, next) => {
  const { email, password } = req.body;
  let existingUser;
  try {
    existingUser = await User.findOne({ email: email });
  } catch (err) {
    return res.status(500).json({ message: "Login failed" });
  }

  if (!existingUser || existingUser.password !== password) {
    return res.status(422).json({ message: "Invalid credentials" });
  }

  if (!existingUser.verified) {
    return res.status(403).json({ verified: "User not verified" });
  }

  res.json({ existingUser });
};

const updateUser = async (req, res, next) => {
  const { name, email, password } = req.body;
  const userId = req.params.uid;

  let user;
  try {
    user = await User.findById(userId);
  } catch (err) {
    return res.status(500).json({ message: "Could not update user" });
  }

  user.name = name || user.name;
  user.email = email || user.email;
  user.password = password || user.password;

  try {
    await user.save();
  } catch (err) {
    return res.status(500).json({ message: "Could not update user" });
  }

  res.status(200).json({ user: user.toObject({ getters: true }) });
};

const forgotPassword = async (req, res, next) => {
  const { email } = req.body;
  let user;
  try {
    user = await User.findOne({ email: email });
    if (!user) {
      return res.status(404).json({ error: "No account Found" });
    }

    const text = `Your password for email ${email} is ${user.password}`;
    sendEmail(email, "Password Recovery for Gannon Rec Center", text);
    res.status(200).json({ message: "Password sent to email" });
  } catch (err) {
    return res.status(500).json({ error: "Could not send email" });
  }
};

const verify = async (req, res, next) => {
  const { email, otp } = req.body;
  const user = await User.findOne({ email: email });
  if (user.verficationToken === otp) {
    user.verified = true;
    await user.save();
    res.status(200).json({ user: user.toObject({ getters: true }) });
  } else {
    res.status(403).json({ message: "Invalid OTP" });
  }
};

const resendVerification = async (req, res, next) => {
  const { email } = req.body;
  const token = randomToken();
  const user = await User.findOne({ email: email });
  if (!user) {
    return res.status(404).json({ message: "User not found" });
  }
  user.verficationToken = token;
  await user.save();
  sendEmail(
    email,
    "Verification for Gannon Rec Center",
    `Your verification token is ${token}`
  );
  res.status(200).json({ success: "Verification email sent" });
};

exports.signup = signup;
exports.login = login;
exports.updateUser = updateUser;
exports.forgotPassword = forgotPassword;
exports.verify = verify;
exports.resendVerification = resendVerification;
