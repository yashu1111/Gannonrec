
const { validationResult } = require('express-validator');

const Activity = require('../models/activity');
const User = require('../models/user');

const createActivity = async (req, res, next) => {

    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        console.log(errors);
        return res.status(422).json({ message: 'Invalid inputs, please check post data' });
    }

    const createdActivity = new Activity({
        title: req.body.title,
        sport: req.body.sport,
        date: req.body.date,
        time: req.body.time,
        nbOfPlayers: req.body.nbOfPlayers,
        description: req.body.description,
        type: req.body.type,
        creator: req.body.creator,
        members: [req.body.creator]
    })

    try {
        await createdActivity.save();
    } catch (err) {
        return res.status(500).json({ message: 'Creating activity failed, please try again' });
    }


    res.status(201).json({ activity: createdActivity });

}


const getActivities = async (req, res, next) => {

    let activities;
    try {
        activities = await Activity.find().populate('creator', 'name').populate('members', 'name').populate('requests', 'name');
    }
    catch (err) {
        return res.status(500).json({ message: 'Fetching activities has failed, please try again later' });
    }

    if (!activities) {
        const error = new Error('Coult not find a activities for the provided ID');
        error.code = 404;
        return next(error);
    }

    res.json({ activities: activities});
}


const getActivitiesOfUser = async (req, res, next) => {

    let userId = req.params.uid;

    let user;
    try {
        user = await User.findById(userId);
    }
    catch (err) {
        return res.status(500).json({ message: 'Something went wrong, could not find a user.' });
    }

    let activities;
    try {
        activities = await Activity.find({ $or: [{ creator: userId }, { members: user }, { requests: user }] }).populate('creator', 'name').populate('members', 'name').populate('requests', 'name');
    }
    catch (err) {
        console.log(err)
        return res.status(500).json({ message: 'Fetching activities has failed, please try again later' });
    }

    if (!activities) {
        const error = new Error('Coult not find a activities for the provided ID');
        error.code = 404;
        return next(error);
    }

    res.json({ activities: activities.map(activity => activity.toObject({ getters: true })) });
}


const getActivityById = async (req, res, next) => {

    let id = req.params.id;

    let activity;
    try {
        activity = await Activity.findById(id).populate('creator', 'name').populate('members', 'name');
    }
    catch (err) {
        return res.status(500).json({ message: 'Fetching activities has failed, please try again later' });
    }

    res.json({ activity: activity})
}


const updateActivityById = async (req, res, next) => {
    let id = req.params.id;
    let activity;
    try {
        activity = await Activity.findById(id);
    }
    catch (err) {
        return res.status(500).json({ message: 'Something went wrong, could not find an activity.' });
    }
    const updatedActivity = {
        title: req.body.title,
        sport: req.body.sport,
        date: req.body.date,
        time: req.body.time,
        nbOfPlayers: req.body.nbOfPlayers,
        description: req.body.description,
        type: req.body.type,
        creator: req.body.creator,
        members: req.body.members
    }

    await Activity.findByIdAndUpdate(id, updatedActivity);

    res.status(200).json({ activity: updatedActivity });
}

const deleteActivityById = async (req, res, next) => {
    let id = req.params.id;
    try {
        await Activity.findById(id);
    }
    catch (err) {
        return res.status(500).json({ message: 'Something went wrong, could not find an activity.' });
    }
    try {
        await Activity.findByIdAndDelete(id);
    } catch (err) {
        return res.status(500).json({ message: 'Something went wrong, could not delete an activity.' });
    }


    res.json({ 'status': 'Activity deleted successfully' });
}

const joinActivity = async (req, res, next) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        console.log(errors);
        return res.status(422).json({ message: 'Invalid inputs, please check post data' });
    }
    let activity;
    try {
        activity = await Activity.findById(req.body.activityId);
    }
    catch (err) {
        return res.status(500).json({ message: 'Something went wrong, could not find an activity.' });
    }

    if (activity.members.length === activity.nbOfPlayers) {
        return res.status(400).json({ message: 'Cannot join activity, player limit full' });
    }

    let user;
    try {
        user = await User.findById(req.body.userId);
    }
    catch (err) {
        return res.status(500).json({ message: 'Something went wrong, could not find a user.' });
    }

    let checkActivity = await Activity.find({ _id: req.body.activityId, $or: [{ members: req.body.userId }, { requests: req.body.userId }] })

    if (checkActivity.length) {
        return res.status(400).json({ message: 'User already joined/requested this activity' });
    }

    if (activity.type === 'Public') {

        await Activity.findByIdAndUpdate(req.body.activityId, { $push: { members: user } });

        return res.json({ 'status': 'Joined Successfully' });

    }
    else if (activity.type === 'Private') {

        await Activity.findByIdAndUpdate(req.body.activityId, { $push: { requests: user } })

        return res.json({ 'status': 'Requested Successfully' });
    }

    return res.status(400).json({ message: 'Invalid activity type' })

}


const declineActivity = async (req, res, next) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        console.log(errors);
        return res.status(422).json({ message: 'Invalid inputs, please check post data' });
    }
    try {
        await Activity.findById(req.body.activityId);
    }
    catch (err) {
        return res.status(500).json({ message: 'Something went wrong, could not find an activity.' });
    }

    try {
        user = await User.findById(req.body.userId);
    }
    catch (err) {
        return res.status(500).json({ message: 'Something went wrong, could not find a user.' });
    }

    let activity = await Activity.find({ _id: req.body.activityId, requests: req.body.userId })

    if (!activity) {
        return res.status(400).json({ message: 'User has not joined this activity' });
    }

    await Activity.findByIdAndUpdate(req.body.activityId, { $pull: { requests: req.body.userId } })

    res.json({ 'status': 'Declined Successfully' });

}


const requestActivity = async (req, res, next) => {

    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        console.log(errors);
        return res.status(422).json({ message: 'Invalid inputs, please check post data' });
    }

    try {
        await Activity.findById(req.body.activityId);
    }
    catch (err) {
        return res.status(500).json({ message: 'Something went wrong, could not find an activity.' });
    }

    let checkActivity = await Activity.find({ _id: req.body.activityId, requests: req.body.userId })
    if (!checkActivity.length) {
        return res.status(400).json({ message: 'User has not requested for this activity' });
    }

    if (req.body.type === 'Accept') {
        await Activity.findByIdAndUpdate(req.body.activityId, { $push: { members: req.body.userId }, $pull: { requests: req.body.userId } })

        return res.json({ 'status': 'Accepted Successfully' });
    }
    else if (req.body.type === 'Decline') {

        await Activity.findByIdAndUpdate(req.body.activityId, { $pull: { requests: req.body.userId } })

        return res.json({ 'status': 'Declined Successfully' });
    }

    return res.status(400).json({ message: 'Invalid request type!' });

}

const removeUser = async (req, res, next) => {

    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        console.log(errors);
        return res.status(422).json({ message: 'Invalid inputs, please check post data' });
    }
    let activity
    try {
        activity = await Activity.findById(req.body.activityId);
    }
    catch (err) {
        return res.status(500).json({ message: 'Something went wrong, could not find an activity.' });
    }

    if (activity.creator._id === req.body.userId) {
        return res.status(400).json({ message: 'Cannot remove creator' });
    }

    let checkActivity = await Activity.find({ _id: req.body.activityId, members: req.body.userId })

    if (!checkActivity.length) {
        return res.status(400).json({ message: 'User is not in this activity' });
    }

    await Activity.findByIdAndUpdate(req.body.activityId, { $pull: { members: req.body.userId } })

    return res.json({ 'status': 'Removed Successfully' });
}

exports.createActivity = createActivity;
exports.getActivities = getActivities;
exports.getActivitiesOfUser = getActivitiesOfUser;
exports.getActivityById = getActivityById;
exports.updateActivityById = updateActivityById;
exports.deleteActivityById = deleteActivityById;
exports.joinActivity = joinActivity;
exports.declineActivity = declineActivity;
exports.requestActivity = requestActivity;
exports.removeUser = removeUser;
